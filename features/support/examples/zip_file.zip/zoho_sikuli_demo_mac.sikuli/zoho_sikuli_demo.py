App.open("Firefox")
wait("WebImagesVid.png",10)
click("httpHwwwguug.png")
type("crm.zoho.com")
click("1308784515564.png")
wait("mmmAffordabl.png",10)
click("1308784583378.png")
wait(6)
click("CUsernameIIE.png")
type("a", KEY_CTRL)
type("joeklienwatir@gmail.com")
click("RasswordZIII.png")
type("a", KEY_CTRL)
type("watir001")
click("1308784882528.png")
wait("TrotherEditi.png",10)
wait (3)
dragDrop("TodaysLeads-1.png", "Welcomejoekl.png")

wait(2)
m=find(Pattern("TrotherEditi.png").similar(0.90))
print m
dragDrop("DpenTasks-1.png","Welcomejoekl-1.png")

m=find(Pattern("TrotherEditi.png").similar(0.90))
print m
click("1308786664493.png")

